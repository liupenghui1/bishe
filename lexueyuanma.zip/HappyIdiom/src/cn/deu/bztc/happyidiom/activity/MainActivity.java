package cn.deu.bztc.happyidiom.activity;

import android.os.Bundle;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.view.Menu;
import android.view.Window;
import android.widget.TabHost;

public class MainActivity extends TabActivity {
	private TabHost  tabHost;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);//ȡ��������
		setContentView(R.layout.activity_main);
		tabHost=getTabHost();
		addTab("study", R.string.title_study, R.drawable.study,StudyActivity.class);
		addTab("search", R.string.title_search, R.drawable.search, StudyActivity.class);
		addTab("study", R.string.title_game, R.drawable.game, StudyActivity.class);
		addTab("save", R.string.title_save, R.drawable.save, StudyActivity.class);
		addTab("help", R.string.title_help, R.drawable.search, StudyActivity.class);
	}
	private void addTab(String tag,int title_introduction,int title_icon,Class ActivityClass){
		tabHost.addTab(tabHost.newTabSpec(tag)
				.setIndicator(getString(title_introduction),
						getResources().getDrawable(title_icon)).setContent(new Intent(this,ActivityClass)));
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
