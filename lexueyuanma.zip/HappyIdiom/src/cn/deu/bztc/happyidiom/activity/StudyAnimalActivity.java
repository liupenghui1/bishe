package cn.deu.bztc.happyidiom.activity;

import java.util.List;

import com.tangsci.android.example.ttsdemo.TtsDemoActivity;

import cn.deu.bztc.happyidiom.activity.adapter.AnimalAdapter;
import cn.deu.bztc.happyidiom.dao.AnimalDao;
import cn.deu.bztc.happyidiom.entity.Animal;
import cn.deu.bztc.happyidiom.util.DialogUtil;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class StudyAnimalActivity  extends Activity{
	private List<Animal> animalList;
	private AnimalDao animalDao;
	private ListView lvAnimalList;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_animal);
		initAnimals();
		lvAnimalList=(ListView) findViewById(R.id.lvAnimalList);
		AnimalAdapter animalAdapter=new AnimalAdapter(this, R.layout.animal_item, animalList);
		lvAnimalList.setAdapter(animalAdapter);
		lvAnimalList.setOnItemClickListener(new OnItemClickListener() {

			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				Animal animal=animalList.get(position);
				final String result=animal.getName	()+"\n"+animal.getPronounce()+
						"\n�����͡�:"+animal.getExplain()+"\n������ʡ�:"+
						animal.getHomoionym()+"\n������ʡ�"+animal.getAntonym()+
						"\n����Դ��"+animal.getDerivation()+"\n��ʾ����"+animal.getExamples();
				DialogUtil.showDialog(result, StudyAnimalActivity.this);
				AlertDialog.Builder  builder=new AlertDialog.Builder(StudyAnimalActivity.this);
				builder.setTitle("�ף����Ƿ����������������");
				builder.setIcon(R.drawable.laba);
				builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {

					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						
					}
				});
				builder.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();//ȡ���Ի���
					}
				});

				builder.create().show();	
				
				
			}
		});
		
		
	}
	private void initAnimals(){
		animalDao=AnimalDao.getInstance(this);
		animalList=AnimalDao.getAllAnimals();
	}
}
