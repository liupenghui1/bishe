package cn.deu.bztc.happyidiom.activity.adapter;

import java.util.List;

import com.tangsci.android.example.ttsdemo.TtsDemoActivity;

import cn.deu.bztc.happyidiom.activity.R;
import cn.deu.bztc.happyidiom.entity.Animal;
import android.content.Context;
import android.content.Intent;
import android.sax.StartElementListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class AnimalAdapter extends ArrayAdapter<Animal> {
	private int resourced;
	private Context context;
	public AnimalAdapter(Context context, int resource, List<Animal> objects) {
		super(context, resource, objects);
		// TODO Auto-generated constructor stub
		this.context=context;
		resourced=resource;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		final	Animal animal=getItem(position);//��ȡ��ǰ��Animalʵ��
		View view;
		ViewHolder  viewHolder;
		if(convertView==null){
			view=LayoutInflater.from(getContext()).inflate(resourced, null);
			viewHolder=new ViewHolder();
			viewHolder.tvName=(TextView) view.findViewById(R.id.tvName);
			viewHolder.btnSave=(ImageButton) view.findViewById(R.id.btnSavae);
			viewHolder.btnSave.setFocusable(false);
			viewHolder.btnSave.setFocusableInTouchMode(false);
			//����ʲô��˼
			viewHolder.btnSave.setOnClickListener(new OnClickListener() {
		
				public void onClick(View v) {
					// TODO Auto-generated method stub
					//Toast.makeText(context, "��Ҫ�ղ�"+animal.getName()+"��", Toast.LENGTH_SHORT).show();
				}
			});

			view.setTag(viewHolder);
		}else{
			view=convertView;
			viewHolder=(ViewHolder) view.getTag();//���»�ȡViewHolder
		}
		viewHolder.tvName.setText(animal.getName());
		return view;
	}
	class ViewHolder{
		TextView  tvName;
		ImageButton btnSave;
	}

}
