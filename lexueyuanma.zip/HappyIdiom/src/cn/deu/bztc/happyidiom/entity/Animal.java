package cn.deu.bztc.happyidiom.entity;

public class Animal {
	private int id;  
	private String name;//��������
	private String pronounce;//���﷢��
	private String explain;//�������
	private String antonym;//�����
	private String homoionym;//ͬ���
	private String derivation;//Դ��
	private String examples;//����
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPronounce() {
		return pronounce;
	}
	public void setPronounce(String pronounce) {
		this.pronounce = pronounce;
	}
	public String getExplain() {
		return explain;
	}
	public void setExplain(String explain) {
		this.explain = explain;
	}
	public String getAntonym() {
		return antonym;
	}
	public void setAntonym(String antonym) {
		this.antonym = antonym;
	}
	public String getHomoionym() {
		return homoionym;
	}
	public void setHomoionym(String homoionym) {
		this.homoionym = homoionym;
	}
	public String getDerivation() {
		return derivation;
	}
	public void setDerivation(String derivation) {
		this.derivation = derivation;
	}
	public String getExamples() {
		return examples;
	}
	public void setExamples(String examples) {
		this.examples = examples;
	}
	
}
