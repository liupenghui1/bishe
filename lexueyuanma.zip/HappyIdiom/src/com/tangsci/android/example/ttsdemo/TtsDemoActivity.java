package com.tangsci.android.example.ttsdemo;
/**
 * Copyright (C) 2015  濉樹笂绉戞妧,tangsci.cn
 */



import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import cn.deu.bztc.happyidiom.activity.R;

import com.tangsci.android.tts.TtsPlayer;
import com.tangsci.tts.TtsEngine;

public class TtsDemoActivity extends Activity
{
    private TextView m_btPlay;
    private TextView m_btPause;
    private TextView m_btStop;
    private TextView m_btMaleVoice;
    private TextView m_btFemaleVoice;
    private TextView m_btClearText;
    private EditText m_etInput;
    private SeekBar m_sbVolume;
    private SeekBar m_sbSpeed;
    private SeekBar m_sbPitch;
    private SeekBar m_sbFreqScale;
    private TextView m_tvVolume;
    private TextView m_tvSpeed;
    private TextView m_tvPitch;
    private TextView m_tvFreqScale;

    String m_playState = "not_ready";

	private Handler m_handler = new Handler()
    {
    	 @Override
         public void handleMessage(Message msg) 
         {
 	        ///鍚堟垚绾跨▼浼氬湪鎾斁瀹屽綋鍓嶆枃鏈鍚庯紝浼氬彂锟�锟斤拷鎾斁瀹屾垚鐨勬秷鎭紝杩欎釜鍑芥暟璐熻矗鎺ユ敹澶勭悊
 	        super.handleMessage(msg);
 	        Bundle b = msg.getData();
 	        String playState = b.getString("play_state");
 	        if (playState == "idle")
 	        {
 	        	setState("idle");
 	        }
         }
    };

    private TtsPlayer m_ttsPlayer = new TtsPlayer(m_handler);

    private boolean initTtsPlay()
    {
        byte[] ttsResBytes;
        InputStream ttsResStream = getResources().openRawResource(R.raw.ttsres);
        try {
            ttsResBytes = new byte[ttsResStream.available()];
            ttsResStream.read(ttsResBytes);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return m_ttsPlayer.initEngine(ttsResBytes);
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        m_playState = "not_ready";
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        m_btPlay = (TextView) findViewById(R.id.Play);
        m_btPlay.setOnClickListener(onClickPlay);
        m_btPause = (TextView) findViewById(R.id.Pause);
        m_btPause.setOnClickListener(onClickPause);
        m_btStop = (TextView) findViewById(R.id.Stop);
        m_btStop.setOnClickListener(onClickStop);
        m_btMaleVoice = (TextView) findViewById(R.id.MaleVoice);
        m_btMaleVoice.setOnClickListener(onClickMaleVoice);
        m_btFemaleVoice = (TextView) findViewById(R.id.FemaleVoice);
        m_btFemaleVoice.setOnClickListener(onClickFemaleVoice);
        m_btClearText = (TextView) findViewById(R.id.ClearText);
        m_btClearText.setOnClickListener(onClickClearText);
        setState("not_ready");

        m_etInput = (EditText) findViewById(R.id.InputText);


        m_sbVolume = (SeekBar) findViewById(R.id.SeekVolume);
        m_sbVolume.setOnSeekBarChangeListener(onSeekBarVolume);
        m_sbSpeed = (SeekBar) findViewById(R.id.SeekSpeed);
        m_sbSpeed.setOnSeekBarChangeListener(onSeekBarSpeed);
        m_sbPitch = (SeekBar) findViewById(R.id.SeekPitch);
        m_sbPitch.setOnSeekBarChangeListener(onSeekBarPitch);
        m_sbFreqScale = (SeekBar) findViewById(R.id.SeekFreqScale);
        m_sbFreqScale.setOnSeekBarChangeListener(onSeekBarFreqScale);

        m_tvVolume = (TextView) findViewById(R.id.Volume);
        m_tvSpeed = (TextView) findViewById(R.id.Speed);
        m_tvPitch = (TextView) findViewById(R.id.Pitch);
        m_tvFreqScale = (TextView) findViewById(R.id.Freqscale);
        Intent  intent=getIntent();
        initTtsPlay();
        ///璇icense code灏嗕簬2018锟�锟�鏃ュ埌锟�        m_ttsPlayer.setGlobalParam("LicenseCode", "GH4V980IOG37H0ADU6IN7HO3");
        ///licenseType锟�0"璇存槑鎺堟潈鎴愬姛
		@SuppressWarnings("unused")
		String licenseType = m_ttsPlayer.getGlobalParam("LicenseType");
		
        
		m_ttsPlayer.setParam("Encoding", TtsEngine.ENCODING_UTF8);///杈撳叆鏂囨湰锟�utf8"缂栫爜
		
        setState("idle");
        

        m_sbFreqScale.setProgress((int) (Math.round((-0.5f + 1.0f) * m_sbFreqScale.getMax() / 2.0f)));
        //String text=palytext(text);
        m_etInput.setText(intent.getStringExtra("result"));
    }
	public void onBackPressed() {
		// TODO Auto-generated method stub
		//super.onBackPressed();
		Intent intent =new Intent();
		intent.putExtra("returndata", true);
		setResult(RESULT_OK, intent);
		//finish();
	}  

 	
    @Override
    public void onDestroy()
    {
        if (null != m_ttsPlayer)
        {
            m_ttsPlayer.uninitEngine();
        }
        super.onDestroy();
    }

    private void setState(String strState)
    {
        m_playState = strState;
        if (m_playState.equals("idle"))
        {
            m_btPlay.setEnabled(true);
            m_btPause.setEnabled(false);
            m_btStop.setEnabled(false);
        }
        else if (m_playState.equals("play"))
        {
            m_btPlay.setEnabled(false);
            m_btPause.setEnabled(true);
            m_btStop.setEnabled(true);
        }
        else if (m_playState.equals("pause"))
        {
            m_btPlay.setEnabled(true);
            m_btPause.setEnabled(false);
            m_btStop.setEnabled(true);
        }
        else if (m_playState.equals("not_ready"))
        {
            m_btPlay.setEnabled(false);
            m_btPause.setEnabled(false);
            m_btStop.setEnabled(false);
        }
    }

    private String getState()
    {
        return m_playState;
    }

    
    
    private OnSeekBarChangeListener onSeekBarVolume = new OnSeekBarChangeListener()
    {
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
        {
            int barLen = seekBar.getMax();
            Float value = (progress - barLen / 2.0f) / barLen * 2.0f;//range(-1.0,1.0)
            m_ttsPlayer.setParam("V", value.toString());//set volume
            m_tvVolume.setText(value.toString());
        }

        public void onStartTrackingTouch(SeekBar seekBar)
        {

        }

        public void onStopTrackingTouch(SeekBar seekBar)
        {

        }
    };
    private OnSeekBarChangeListener onSeekBarSpeed = new OnSeekBarChangeListener()
    {
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
        {
            int barLen = seekBar.getMax();
            Float value = (progress - barLen / 2.0f) / barLen * 2.0f;//range(-1.0,1.0)
            m_ttsPlayer.setParam("S", value.toString());//set speed
            m_tvSpeed.setText(value.toString());
        }

        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };
    private OnSeekBarChangeListener onSeekBarPitch = new OnSeekBarChangeListener()
    {
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
        {
            int barLen = seekBar.getMax();
            Float value = (progress - barLen / 2.0f) / barLen * 2.0f;//range(-1.0,1.0)
            m_ttsPlayer.setParam("P", value.toString());//set pitch
            m_tvPitch.setText(value.toString());
        }

        public void onStartTrackingTouch(SeekBar seekBar)
        {

        }

        public void onStopTrackingTouch(SeekBar seekBar)
        {

        }
    };
    private OnSeekBarChangeListener onSeekBarFreqScale = new OnSeekBarChangeListener()
    {

		public void onProgressChanged(SeekBar seekBar, int progress,
				boolean fromUser) 
		{
			// TODO Auto-generated method stub
			int barLen = seekBar.getMax();
            Float value = (progress - barLen / 2.0f) / barLen * 2.0f;//range(-1.0,1.0)
            m_ttsPlayer.setParam("F", value.toString());//set freqscale
            m_tvFreqScale.setText(value.toString());
		}

		public void onStartTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			
		}

		public void onStopTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			
		}
    	
    };
    
    private OnClickListener onClickPlay = new OnClickListener()
    {
        @SuppressWarnings("unused")
		boolean rt;
        public void onClick(View v)
        {
            String strCurState = getState();
            if (strCurState.equals("play") || strCurState.equals("not_ready"))
            {
                return;
            }
            if (strCurState.equals("idle"))
            {
                String inputText = m_etInput.getText().toString();
                rt = m_ttsPlayer.playText(inputText);
            }
            else if (strCurState.equals("pause"))
            {
                m_ttsPlayer.play();
            }
            setState("play");
        }
    };
    private OnClickListener onClickPause = new OnClickListener()
    {
        public void onClick(View v)
        {
            m_ttsPlayer.pause();
            setState("pause");
        }
    };
    private OnClickListener onClickStop = new OnClickListener()
    {
        public void onClick(View v)
        {
            m_ttsPlayer.stop();
            //setState("stop");//褰撳綋鍓嶅悎鎴愪换鍔″仠姝㈡垨鑰呯粓姝㈡椂锛宧andleMessage浼氭帴鏀跺埌娑堟伅
        }
    };
    private OnClickListener onClickMaleVoice = new OnClickListener()
    {
        public void onClick(View v)
        {
            //male voice:pitch=-0.45,freqscale=-0.5
            m_sbPitch.setProgress((int) (Math.round((-0.45f + 1.0f) * m_sbPitch.getMax() / 2.0f)));
            m_sbFreqScale.setProgress((int) (Math.round((-0.5f + 1.0f) * m_sbFreqScale.getMax() / 2.0f)));
        }
    };
    private OnClickListener onClickFemaleVoice = new OnClickListener()
    {
        public void onClick(View v)
        {
            //female voice:pitch=0.25,freqscale=0
            m_sbPitch.setProgress((int) (Math.round((0.25f + 1.0f) * m_sbPitch.getMax() / 2.0f)));
            m_sbFreqScale.setProgress((int) (Math.round((0.0f + 1.0f) * m_sbFreqScale.getMax() / 2.0f)));
        }
    };
    private OnClickListener onClickClearText = new OnClickListener()
    {
        public void onClick(View v)
        {
            m_etInput.setText("");
        }
    };
}
